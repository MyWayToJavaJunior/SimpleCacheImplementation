package ru.dobrovolsky.cache.strategies;

public enum Strategies {
    LRU,
    LFU
}
