#!/usr/bin/env bash

java -jar simpleCache.jar -capacity 3 -strategy LFU
